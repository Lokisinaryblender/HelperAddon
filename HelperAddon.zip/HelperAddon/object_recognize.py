import bpy

def recognize_selected_object():
    active_object = bpy.context.view_layer.objects.active

    if active_object:
        return f"Recognized object: {active_object.name}"
    else:
        return "No object selected"
