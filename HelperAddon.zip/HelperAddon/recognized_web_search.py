import bpy
import webbrowser
from .object_recognize import recognize_selected_object

def search_web_for_recognized_object():
    recognized_object = recognize_selected_object()
    if "No object selected" in recognized_object:
        return "No object selected. Please select an object."
    else:
        search_query = f"Blender {recognized_object} tutorial"
        search_url = f"https://www.google.com/search?q={search_query}"
        webbrowser.open_new_tab(search_url)
        return f"Google Searching for '{search_query}'..."
    
class OBJECT_OT_WebSearchOperator(bpy.types.Operator):
    bl_idname = "object.web_search"
    bl_label = "Google Search"
    bl_description = "Perform a Google search for the recognized object"
    
    def execute(self, context):
        message = search_web_for_recognized_object()
        self.report({'INFO'}, message)
        return {'FINISHED'}

class OBJECT_OT_YouTubeSearchOperator(bpy.types.Operator):
    bl_idname = "object.youtube_search"
    bl_label = "YouTube Search"
    bl_description = "Perform a YouTube search for the recognized object"
    
    def execute(self, context):
        recognized_object = recognize_selected_object()
        if "No object selected" in recognized_object:
            return {'CANCELLED'}
        else:
            search_query = f"Blender {recognized_object} tutorial"
            search_url = f"https://www.youtube.com/results?search_query={search_query}"
            webbrowser.open_new_tab(search_url)
            return {'FINISHED'}
