import os
import bpy
from .object_recognize import recognize_selected_object
from .recognized_web_search import search_web_for_recognized_object, OBJECT_OT_WebSearchOperator, OBJECT_OT_YouTubeSearchOperator  # Import the operators
from .text_web_search import OBJECT_OT_TextWebSearchOperator
import webbrowser

class HelperPanel(bpy.types.Panel):
    bl_label = "Helper Panel"
    bl_idname = "PT_HelperPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Helper'
    bl_description = "A collection of tools to assist with object recognition and web searches in Blender"
    bl_version = (1, 0)
    bl_author = "lokisianry"

    def draw(self, context):
        layout = self.layout

        # Add a button to execute the operator
        layout.operator("object.helper")

        # Get the recognized object
        recognized_object = recognize_selected_object()

        if "No object selected" in recognized_object:
            layout.label(text=recognized_object)
            layout.operator("object.web_search", text="Search Web")  # Use the Text Web Search operator
        else:
            recognized_object_name = recognized_object.replace("Recognized object: ", "")
            layout.label(text=recognized_object)
            row = layout.row(align=True)
            row.operator("object.web_search", text=f"Google '{recognized_object_name}'")   # Use the Google Search operator
            row.operator("object.youtube_search", text=f"YouTube '{recognized_object_name}'")  # Use the YouTube Search operator

        # Add a separator
        layout.separator()

        # Add the text web search input field with enhanced visual effects
        layout.label(text="Text Web Search:")
        custom_search_row = layout.row(align=True)
        custom_search_row.prop(context.scene, "custom_search_text", text="", emboss=True, icon='VIEWZOOM')
        text_search_row = layout.row(align=True)
        text_search_row.operator("object.text_web_search", text="Google").search_engine = 'google'  # Use the Text Web Search operator for Google
        text_search_row.operator("object.text_web_search", text="YouTube").search_engine = 'youtube'  # Use the Text Web Search operator for YouTube

        addon_directory = os.path.dirname(__file__)
        readme_path = os.path.join(addon_directory, "README.md")

        # Add a separator
        layout.separator()

        info_box = layout.box()
        info_box.operator("wm.url_open", text="Addon Information", icon='SETTINGS').url = "file://" + readme_path
        info_box.label(text=f"Author: {self.bl_author}", icon='USER')
        info_box.label(text=f"Version: {self.bl_version[0]}.{self.bl_version[1]}", icon='INFO')

classes = (
    HelperPanel,
    OBJECT_OT_TextWebSearchOperator,  # Include the text web search operator here
    OBJECT_OT_WebSearchOperator,  # Include the recognized web search operator here
    OBJECT_OT_YouTubeSearchOperator,  # Include the YouTube search operator here
)

def register():
    bpy.types.Scene.custom_search_text = bpy.props.StringProperty(name="Custom Search Text")
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.custom_search_text

if __name__ == "__main__":
    register()
