bl_info = {
    "name": "Helper Add-on",
    "author": "lokisinary",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Helper Panel",
    "description": "A helpful add-on for object recognition and web searches in Blender.",
    "category": "Object",
}
import bpy
from . import ui  # Import the ui module

def register():
    ui.register()

def unregister():
    ui.unregister()

if __name__ == "__main__":
    register()
